package com.example.padtool

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.max

class MainActivity : Activity() {

    private enum class Step { IDLE, SOURCE, TARGET }

    private lateinit var store: ProfileStore
    private lateinit var profile: Profile
    private lateinit var pad: GamepadView
    private lateinit var status: TextView
    private lateinit var remapBtn: Button
    private lateinit var remapInfo: TextView
    private var device: InputDevice? = null

    // Remapeamento
    private var step = Step.IDLE
    private var source = 0

    // O D-pad do DS4 chega como eixo (hat). Eu converto em botões virtuais para poder remapear.
    private var lastHx = 0f
    private var lastHy = 0f
    private val hatHeld = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        profile = store.load()

        pad = GamepadView(this).also { it.profile = profile }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        status = label("Conecte o controle e mexa em qualquer botão.")
        panel.addView(status)

        panel.addView(slider("Zona morta", (profile.deadzone / 0.5f * 100).toInt(),
            { "%.0f%%".format(it / 100f * 0.5f * 100) }) {
            profile.deadzone = it / 100f * 0.5f
        })
        panel.addView(slider("Curva (1.0 = linear)", ((profile.curve - 0.5f) / 2.5f * 100).toInt(),
            { "%.2f".format(0.5f + it / 100f * 2.5f) }) {
            profile.curve = 0.5f + it / 100f * 2.5f
        })
        panel.addView(slider("Vibração", (profile.vibration * 100).toInt(),
            { "$it%" }) {
            profile.vibration = it / 100f
        })

        panel.addView(CheckBox(this).apply {
            text = "Inverter eixo Y"
            setTextColor(Color.WHITE)
            isChecked = profile.invertY
            setOnCheckedChangeListener { _, checked ->
                profile.invertY = checked
                store.save(profile)
                pad.invalidate()
            }
        })

        panel.addView(Button(this).apply {
            text = "Testar vibração"
            setOnClickListener { testVibration() }
        })

        panel.addView(Button(this).apply {
            text = "Diagnóstico (Shizuku)"
            setOnClickListener { startActivity(Intent(this@MainActivity, DiagActivity::class.java)) }
        })

        // ---- Remapeamento ----
        panel.addView(label("\nRemapeamento de botões").apply { textSize = 16f })
        remapBtn = Button(this).apply {
            text = "Remapear um botão"
            setOnClickListener { toggleRemap() }
        }
        panel.addView(remapBtn)
        panel.addView(Button(this).apply {
            text = "Limpar remapeamentos"
            setOnClickListener {
                profile.remap.clear()
                store.save(profile)
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
        })
        remapInfo = label("")
        panel.addView(remapInfo)
        refreshRemapInfo()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(18, 18, 24))
        }
        root.addView(pad, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 3f))
        root.addView(ScrollView(this).apply { addView(panel) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f))
        setContentView(root)
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE) }

    private fun slider(name: String, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): LinearLayout {
        val title = label("$name: ${fmt(start)}")
        val bar = SeekBar(this).apply {
            max = 100
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    title.text = "$name: ${fmt(p)}"
                    onChange(p)
                    pad.invalidate()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { store.save(profile) }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 16, 0, 16)
            addView(title)
            addView(bar)
        }
    }

    // ---- Remapeamento: 1) aperte o botão a trocar  2) aperte o botão que ele deve virar ----

    private fun toggleRemap() {
        if (step == Step.IDLE) {
            step = Step.SOURCE
            remapBtn.text = "Cancelar"
            remapInfo.text = "Passo 1: aperte no controle o botão que você quer trocar."
        } else {
            step = Step.IDLE
            remapBtn.text = "Remapear um botão"
            refreshRemapInfo()
        }
    }

    private fun handleRemapPress(code: Int) {
        when (step) {
            Step.SOURCE -> {
                source = code
                step = Step.TARGET
                remapInfo.text = "Passo 2: ${buttonName(code)} vai virar qual botão? Aperte o botão de destino.\n(Aperte o mesmo botão para desfazer a troca.)"
            }
            Step.TARGET -> {
                if (code == source) profile.remap.remove(source) else profile.remap[source] = code
                store.save(profile)
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
            Step.IDLE -> {}
        }
    }

    private fun refreshRemapInfo() {
        remapInfo.text = if (profile.remap.isEmpty()) {
            "Nenhum remapeamento. Aperte um botão para ver como fica."
        } else {
            profile.remap.entries.joinToString("\n") {
                "${buttonName(it.key)} → ${buttonName(it.value)}"
            }
        }
    }

    // ---- Entrada do controle ----

    private fun handleHat(hx: Float, hy: Float) {
        if (hx == lastHx && hy == lastHy) return
        lastHx = hx
        lastHy = hy
        pad.state.pressed.removeAll(hatHeld)
        hatHeld.clear()
        val raw = listOfNotNull(
            if (hy < -0.5f) KeyEvent.KEYCODE_DPAD_UP else null,
            if (hy > 0.5f) KeyEvent.KEYCODE_DPAD_DOWN else null,
            if (hx < -0.5f) KeyEvent.KEYCODE_DPAD_LEFT else null,
            if (hx > 0.5f) KeyEvent.KEYCODE_DPAD_RIGHT else null
        )
        if (step != Step.IDLE) {
            val first = raw.firstOrNull()
            if (first != null) handleRemapPress(first)
        } else {
            for (code in raw) {
                val mapped = profile.map(code)
                hatHeld.add(mapped)
                pad.state.pressed.add(mapped)
            }
        }
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.action == MotionEvent.ACTION_MOVE) {
            val s = pad.state
            s.lx = e.getAxisValue(MotionEvent.AXIS_X)
            s.ly = e.getAxisValue(MotionEvent.AXIS_Y)
            s.rx = e.getAxisValue(MotionEvent.AXIS_Z)
            s.ry = e.getAxisValue(MotionEvent.AXIS_RZ)
            s.lt = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
            s.rt = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
            handleHat(e.getAxisValue(MotionEvent.AXIS_HAT_X), e.getAxisValue(MotionEvent.AXIS_HAT_Y))
            setDevice(e.device)
            pad.invalidate()
            return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val fromPad = e.isFromSource(InputDevice.SOURCE_GAMEPAD) || e.isFromSource(InputDevice.SOURCE_DPAD)
        val isPadKey = KeyEvent.isGamepadButton(e.keyCode) ||
            e.keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        if (!fromPad || !isPadKey) return super.dispatchKeyEvent(e)

        setDevice(e.device)

        if (step != Step.IDLE) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) handleRemapPress(e.keyCode)
            return true
        }

        val mapped = profile.map(e.keyCode)
        if (e.action == KeyEvent.ACTION_DOWN) pad.state.pressed.add(mapped)
        else if (e.action == KeyEvent.ACTION_UP) pad.state.pressed.remove(mapped)
        pad.invalidate()
        return true
    }

    private fun setDevice(d: InputDevice?) {
        if (d == null || d.id == device?.id) return
        device = d
        var info = "Controle: ${d.name}"
        if (Build.VERSION.SDK_INT >= 31) {
            val b = d.batteryState
            if (b.isPresent && !b.capacity.isNaN()) info += "\nBateria: ${(b.capacity * 100).toInt()}%"
        }
        status.text = info
    }

    private fun testVibration() {
        val d = device ?: return
        val amp = max(1, (profile.vibration * 255).toInt())
        if (Build.VERSION.SDK_INT >= 31) {
            val v = d.vibratorManager.defaultVibrator
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(400, amp))
        } else {
            @Suppress("DEPRECATION")
            d.vibrator.vibrate(400)
        }
    }
}
