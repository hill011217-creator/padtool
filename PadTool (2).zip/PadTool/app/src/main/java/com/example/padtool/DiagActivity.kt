package com.example.padtool

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

/**
 * Tela de diagnóstico: só LÊ informações do sistema pelo Shizuku.
 * Não injeta nada nem altera o controle. Serve para descobrir o que é possível.
 */
class DiagActivity : Activity(),
    Shizuku.OnRequestPermissionResultListener,
    Shizuku.OnBinderReceivedListener,
    Shizuku.OnBinderDeadListener {

    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var runBtn: Button

    private fun alive(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    private fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
        output = TextView(this).apply {
            setTextColor(Color.rgb(170, 255, 170))
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            text = "Toque em \"Rodar diagnóstico\" para começar."
        }

        val permBtn = Button(this).apply {
            text = "1) Pedir permissão do Shizuku"
            setOnClickListener { askPermission() }
        }
        runBtn = Button(this).apply {
            text = "2) Rodar diagnóstico"
            setOnClickListener { runDiagnostic() }
        }
        val copyBtn = Button(this).apply {
            text = "3) Copiar resultado"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("padtool-diag", output.text))
                Toast.makeText(this@DiagActivity, "Copiado. Cole na conversa.", Toast.LENGTH_SHORT).show()
            }
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            addView(TextView(this@DiagActivity).apply {
                text = "Diagnóstico (Shizuku)"
                setTextColor(Color.WHITE)
                textSize = 20f
            })
            addView(status)
            addView(permBtn)
            addView(runBtn)
            addView(copyBtn)
            addView(output)
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.rgb(18, 18, 24))
            addView(panel)
        })

        Shizuku.addRequestPermissionResultListener(this)
        Shizuku.addBinderReceivedListenerSticky(this)
        Shizuku.addBinderDeadListener(this)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(this)
        Shizuku.removeBinderReceivedListener(this)
        Shizuku.removeBinderDeadListener(this)
        super.onDestroy()
    }

    override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
        runOnUiThread { refreshStatus() }
    }

    override fun onBinderReceived() {
        runOnUiThread { refreshStatus() }
    }

    override fun onBinderDead() {
        runOnUiThread { refreshStatus() }
    }

    private fun refreshStatus() {
        val sb = StringBuilder()
        if (!alive()) {
            sb.append("Shizuku: NÃO está ativo.\n")
            sb.append("Abra o app Shizuku e toque em Iniciar (pela Depuração sem fio), depois volte aqui.")
        } else {
            val uid = try { Shizuku.getUid() } catch (t: Throwable) { -1 }
            val who = when (uid) {
                0 -> "root"
                2000 -> "adb/shell"
                else -> "uid $uid"
            }
            sb.append("Shizuku: ativo ($who)\n")
            sb.append(
                if (granted()) "Permissão: concedida"
                else "Permissão: ainda não concedida. Toque no botão 1."
            )
        }
        status.text = sb.toString()
    }

    private fun askPermission() {
        if (!alive()) {
            Toast.makeText(this, "Shizuku não está ativo.", Toast.LENGTH_LONG).show()
            return
        }
        if (granted()) {
            Toast.makeText(this, "Já tem permissão.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                Toast.makeText(
                    this,
                    "Permissão negada antes. Libere o PadTool dentro do app Shizuku.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (t: Throwable) {
            Toast.makeText(this, "Erro: $t", Toast.LENGTH_LONG).show()
        }
    }

    // O método newProcess é privado nas versões novas da API, então chamo por reflexão.
    private fun shell(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim().ifEmpty { "(sem saída)" }
        } catch (t: Throwable) {
            "ERRO: ${t.cause ?: t}"
        }
    }

    private fun runDiagnostic() {
        if (!alive()) {
            Toast.makeText(this, "Shizuku não está ativo.", Toast.LENGTH_LONG).show()
            return
        }
        if (!granted()) {
            Toast.makeText(this, "Falta a permissão (botão 1).", Toast.LENGTH_LONG).show()
            return
        }
        runBtn.isEnabled = false
        output.text = "Rodando..."

        val tests = listOf(
            "Aparelho" to "getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk",
            "Quem sou eu" to "id",
            "Arquivos de entrada (/dev/input)" to "ls -l /dev/input",
            "O shell consegue LER cada dispositivo?" to
                "for f in /dev/input/event*; do if [ -r \"\$f\" ]; then echo \"\$f: leitura OK\"; else echo \"\$f: SEM leitura\"; fi; done",
            "uinput (criar controle virtual)" to
                "ls -l /dev/uinput; if [ -w /dev/uinput ]; then echo 'escrita OK'; else echo 'SEM escrita'; fi",
            "Lista de dispositivos de entrada" to
                "cat /proc/bus/input/devices | grep -E '^(N:|H:)'",
            "Eixos e botões (getevent)" to "getevent -pl | head -n 120"
        )

        thread {
            val sb = StringBuilder()
            for ((title, cmd) in tests) {
                sb.append("=== ").append(title).append(" ===\n")
                sb.append(shell(cmd)).append("\n\n")
            }
            runOnUiThread {
                output.text = sb.toString()
                runBtn.isEnabled = true
            }
        }
    }
}
