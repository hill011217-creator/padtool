package com.example.padtool

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.View
import kotlin.math.min

class PadState {
    var lx = 0f; var ly = 0f
    var rx = 0f; var ry = 0f
    var lt = 0f; var rt = 0f
    var hatX = 0f; var hatY = 0f
    val pressed = mutableSetOf<Int>()
}

/** Desenha o controle: cinza = valor bruto, colorido = depois do perfil. */
class GamepadView(ctx: Context) : View(ctx) {
    val state = PadState()
    var profile = Profile()
    /** true = o valor já veio processado pelo motor; não aplicar o perfil de novo. */
    var passthrough = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.GRAY }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }

    private val on = Color.rgb(0, 170, 255)
    private val off = Color.rgb(50, 50, 62)

    // Mostra o botão de SAÍDA: se Cross foi remapeado para Circle, apertar Cross acende Circle.
    private fun down(vararg codes: Int) = codes.any { out ->
        state.pressed.any { p -> (if (passthrough) p else profile.map(p)) == out }
    }

    private fun tv(v: Float) = if (passthrough) v else profile.trigger(v)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val u = min(w, h)
        text.textSize = u * 0.045f
        c.drawColor(Color.rgb(18, 18, 24))

        // Gatilhos e ombros
        trigger(c, w * 0.04f, h * 0.03f, w * 0.30f, h * 0.07f, tv(state.lt), "L2")
        trigger(c, w * 0.66f, h * 0.03f, w * 0.30f, h * 0.07f, tv(state.rt), "R2")
        pill(c, w * 0.04f, h * 0.12f, w * 0.30f, h * 0.06f, down(KeyEvent.KEYCODE_BUTTON_L1), "L1")
        pill(c, w * 0.66f, h * 0.12f, w * 0.30f, h * 0.06f, down(KeyEvent.KEYCODE_BUTTON_R1), "R1")

        // D-pad
        val d = u * 0.13f
        val dx = w * 0.16f; val dy = h * 0.40f; val br = u * 0.055f
        circle(c, dx, dy - d, br, down(KeyEvent.KEYCODE_DPAD_UP), "↑")
        circle(c, dx, dy + d, br, down(KeyEvent.KEYCODE_DPAD_DOWN), "↓")
        circle(c, dx - d, dy, br, down(KeyEvent.KEYCODE_DPAD_LEFT), "←")
        circle(c, dx + d, dy, br, down(KeyEvent.KEYCODE_DPAD_RIGHT), "→")

        // Botões de ação (A/B/X/Y do Android = X/○/□/△ do DS4)
        val fx = w * 0.84f
        circle(c, fx, dy - d, br, down(KeyEvent.KEYCODE_BUTTON_Y), "△")
        circle(c, fx, dy + d, br, down(KeyEvent.KEYCODE_BUTTON_A), "✕")
        circle(c, fx - d, dy, br, down(KeyEvent.KEYCODE_BUTTON_X), "□")
        circle(c, fx + d, dy, br, down(KeyEvent.KEYCODE_BUTTON_B), "○")

        // Centro
        pill(c, w * 0.36f, h * 0.30f, w * 0.10f, h * 0.06f, down(KeyEvent.KEYCODE_BUTTON_SELECT), "Share")
        pill(c, w * 0.54f, h * 0.30f, w * 0.10f, h * 0.06f, down(KeyEvent.KEYCODE_BUTTON_START), "Options")
        circle(c, w * 0.5f, h * 0.43f, br, down(KeyEvent.KEYCODE_BUTTON_MODE), "PS")

        // Analógicos
        val sr = u * 0.17f
        stick(c, w * 0.34f, h * 0.74f, sr, state.lx, state.ly, down(KeyEvent.KEYCODE_BUTTON_THUMBL), "L3")
        stick(c, w * 0.66f, h * 0.74f, sr, state.rx, state.ry, down(KeyEvent.KEYCODE_BUTTON_THUMBR), "R3")
    }

    private fun circle(c: Canvas, x: Float, y: Float, r: Float, pressed: Boolean, label: String) {
        fill.color = if (pressed) on else off
        c.drawCircle(x, y, r, fill)
        c.drawCircle(x, y, r, line)
        c.drawText(label, x, y + text.textSize * 0.35f, text)
    }

    private fun pill(c: Canvas, l: Float, t: Float, w: Float, h: Float, pressed: Boolean, label: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = if (pressed) on else off
        c.drawRoundRect(rect, h / 2, h / 2, fill)
        c.drawRoundRect(rect, h / 2, h / 2, line)
        c.drawText(label, rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
    }

    private fun trigger(c: Canvas, l: Float, t: Float, w: Float, h: Float, v: Float, label: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = off
        c.drawRoundRect(rect, 12f, 12f, fill)
        fill.color = on
        c.drawRoundRect(RectF(l, t, l + w * v, t + h), 12f, 12f, fill)
        c.drawRoundRect(rect, 12f, 12f, line)
        c.drawText("$label  ${"%.2f".format(v)}", rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
    }

    private fun stick(c: Canvas, cx: Float, cy: Float, r: Float, rawX: Float, rawY: Float, pressed: Boolean, label: String) {
        fill.color = if (pressed) Color.rgb(0, 90, 140) else Color.rgb(30, 30, 40)
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, line)
        // zona morta configurada
        val dz = Paint(line).apply { color = Color.rgb(120, 80, 80); pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 10f), 0f) }
        c.drawCircle(cx, cy, r * profile.deadzone, dz)
        // valor bruto (cinza)
        fill.color = Color.GRAY
        c.drawCircle(cx + rawX * r, cy + rawY * r, r * 0.12f, fill)
        // valor processado (azul)
        val (px, py) = if (passthrough) (rawX to rawY) else profile.stick(rawX, rawY)
        fill.color = on
        c.drawCircle(cx + px * r, cy + py * r, r * 0.16f, fill)
        c.drawText(label, cx, cy - r - 10f, text)
        c.drawText("%.2f  %.2f".format(px, py), cx, cy + r + text.textSize + 6f, text)
    }
}
