package com.example.padtool

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.concurrent.thread
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private enum class Step { IDLE, SOURCE, TARGET }

    private lateinit var store: ProfileStore
    private lateinit var profile: Profile
    private lateinit var pad: GamepadView
    private lateinit var status: TextView
    private lateinit var remapBtn: Button
    private lateinit var remapInfo: TextView
    private var device: InputDevice? = null

    // Motor (roda em segundo plano pelo Shizuku)
    private lateinit var engineStatus: TextView
    private var engineOn = false
    private val handler = Handler(Looper.getMainLooper())
    private val statusTick = object : Runnable {
        override fun run() {
            thread {
                val s = PadEngineCtl.status()
                runOnUiThread { applyEngineStatus(s) }
            }
            handler.postDelayed(this, 2500)
        }
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { startEngine() }
        }
    }

    // Remapeamento
    private var step = Step.IDLE
    private var source = 0

    // O D-pad do DS4 chega como eixo (hat). Eu converto em botões virtuais para poder remapear.
    private var lastHx = 0f
    private var lastHy = 0f
    private val hatHeld = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        profile = store.load()

        pad = GamepadView(this).also { it.profile = profile }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        status = label("Conecte o controle e mexa em qualquer botão.")
        panel.addView(status)

        // ---- Motor (vale dentro dos jogos) ----
        panel.addView(label("\nMotor (vale dentro dos jogos)").apply { textSize = 16f })
        engineStatus = label("Motor: verificando...")
        panel.addView(engineStatus)
        panel.addView(Button(this).apply {
            text = "Ativar motor (Shizuku)"
            setOnClickListener { startEngine() }
        })
        panel.addView(Button(this).apply {
            text = "Desativar motor"
            setOnClickListener { stopEngine() }
        })
        panel.addView(label("Com o motor ativo, o PS4 passa por aqui e os ajustes valem em qualquer jogo. Ative antes de abrir o jogo.").apply { textSize = 12f })
        panel.addView(label("").apply { textSize = 4f })

        panel.addView(slider("Zona morta", (profile.deadzone / 0.5f * 100).toInt(),
            { "%.0f%%".format(it / 100f * 0.5f * 100) }) {
            profile.deadzone = it / 100f * 0.5f
        })
        panel.addView(slider("Curva (1.0 = linear)", ((profile.curve - 0.5f) / 2.5f * 100).toInt(),
            { "%.2f".format(0.5f + it / 100f * 2.5f) }) {
            profile.curve = 0.5f + it / 100f * 2.5f
        })
        panel.addView(slider("Vibração", (profile.vibration * 100).toInt(),
            { "$it%" }) {
            profile.vibration = it / 100f
        })

        panel.addView(CheckBox(this).apply {
            text = "Inverter eixo Y"
            setTextColor(Color.WHITE)
            isChecked = profile.invertY
            setOnCheckedChangeListener { _, checked ->
                profile.invertY = checked
                store.save(profile)
                pushEngine()
                pad.invalidate()
            }
        })

        panel.addView(Button(this).apply {
            text = "Testar vibração"
            setOnClickListener { testVibration() }
        })

        panel.addView(Button(this).apply {
            text = "Diagnóstico (Shizuku)"
            setOnClickListener { startActivity(Intent(this@MainActivity, DiagActivity::class.java)) }
        })

        // ---- Remapeamento ----
        panel.addView(label("\nRemapeamento de botões").apply { textSize = 16f })
        remapBtn = Button(this).apply {
            text = "Remapear um botão"
            setOnClickListener { toggleRemap() }
        }
        panel.addView(remapBtn)
        panel.addView(Button(this).apply {
            text = "Limpar remapeamentos"
            setOnClickListener {
                profile.remap.clear()
                store.save(profile)
                pushEngine()
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
        })
        remapInfo = label("")
        panel.addView(remapInfo)
        refreshRemapInfo()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(18, 18, 24))
        }
        root.addView(pad, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 3f))
        root.addView(ScrollView(this).apply { addView(panel) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f))
        setContentView(root)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onResume() {
        super.onResume()
        handler.post(statusTick)
    }

    override fun onPause() {
        handler.removeCallbacks(statusTick)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---- Motor ----

    private fun applyEngineStatus(s: String) {
        engineOn = s.startsWith("RODANDO")
        engineStatus.text = when {
            s.startsWith("SEM_SHIZUKU") -> "Motor: parado. O Shizuku não está ativo (abra o app Shizuku e toque em Iniciar)."
            s.startsWith("SEM_PERMISSAO") -> "Motor: parado. Toque em Ativar e aceite a permissão do Shizuku."
            s.startsWith("PARADO") -> "Motor: parado."
            s.startsWith("RODANDO") -> "Motor: ativo.\n" + s.removePrefix("RODANDO").trim()
            else -> "Motor: $s"
        }
    }

    private fun snapshot(): Profile = profile.copy(remap = profile.remap.toMutableMap())

    private fun pushEngine() {
        if (!engineOn) return
        val snap = snapshot()
        thread { PadEngineCtl.pushConfig(snap) }
    }

    private fun startEngine() {
        if (!PadEngineCtl.alive()) {
            Toast.makeText(this, "Shizuku não está ativo. Abra o app Shizuku e toque em Iniciar.", Toast.LENGTH_LONG).show()
            return
        }
        if (!PadEngineCtl.granted()) {
            try {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    Toast.makeText(this, "Permissão negada antes. Libere o PadTool dentro do app Shizuku.", Toast.LENGTH_LONG).show()
                } else {
                    Shizuku.requestPermission(1002)
                }
            } catch (t: Throwable) {
                Toast.makeText(this, "Erro: $t", Toast.LENGTH_LONG).show()
            }
            return
        }
        engineStatus.text = "Motor: iniciando..."
        val apk = applicationInfo.sourceDir
        val snap = snapshot()
        thread {
            PadEngineCtl.start(apk, snap)
            Thread.sleep(2500)
            val s = PadEngineCtl.status()
            runOnUiThread { applyEngineStatus(s) }
        }
    }

    private fun stopEngine() {
        if (!PadEngineCtl.alive() || !PadEngineCtl.granted()) {
            applyEngineStatus(PadEngineCtl.status())
            return
        }
        engineStatus.text = "Motor: parando..."
        thread {
            PadEngineCtl.stop()
            val s = PadEngineCtl.status()
            runOnUiThread { applyEngineStatus(s) }
        }
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE) }

    private fun slider(name: String, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): LinearLayout {
        val title = label("$name: ${fmt(start)}")
        val bar = SeekBar(this).apply {
            max = 100
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    title.text = "$name: ${fmt(p)}"
                    onChange(p)
                    pad.invalidate()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { store.save(profile); pushEngine() }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 16, 0, 16)
            addView(title)
            addView(bar)
        }
    }

    // ---- Remapeamento: 1) aperte o botão a trocar  2) aperte o botão que ele deve virar ----

    private fun toggleRemap() {
        if (step == Step.IDLE) {
            if (engineOn) {
                Toast.makeText(this, "Desative o motor para criar remapeamentos.", Toast.LENGTH_LONG).show()
                return
            }
            step = Step.SOURCE
            remapBtn.text = "Cancelar"
            remapInfo.text = "Passo 1: aperte no controle o botão que você quer trocar."
        } else {
            step = Step.IDLE
            remapBtn.text = "Remapear um botão"
            refreshRemapInfo()
        }
    }

    private fun handleRemapPress(code: Int) {
        when (step) {
            Step.SOURCE -> {
                source = code
                step = Step.TARGET
                remapInfo.text = "Passo 2: ${buttonName(code)} vai virar qual botão? Aperte o botão de destino.\n(Aperte o mesmo botão para desfazer a troca.)"
            }
            Step.TARGET -> {
                if (code == source) profile.remap.remove(source) else profile.remap[source] = code
                store.save(profile)
                pushEngine()
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
            Step.IDLE -> {}
        }
    }

    private fun refreshRemapInfo() {
        remapInfo.text = if (profile.remap.isEmpty()) {
            "Nenhum remapeamento. Aperte um botão para ver como fica."
        } else {
            profile.remap.entries.joinToString("\n") {
                "${buttonName(it.key)} → ${buttonName(it.value)}"
            }
        }
    }

    // ---- Entrada do controle ----

    private fun handleHat(hx: Float, hy: Float) {
        if (hx == lastHx && hy == lastHy) return
        lastHx = hx
        lastHy = hy
        pad.state.pressed.removeAll(hatHeld)
        hatHeld.clear()
        val raw = listOfNotNull(
            if (hy < -0.5f) KeyEvent.KEYCODE_DPAD_UP else null,
            if (hy > 0.5f) KeyEvent.KEYCODE_DPAD_DOWN else null,
            if (hx < -0.5f) KeyEvent.KEYCODE_DPAD_LEFT else null,
            if (hx > 0.5f) KeyEvent.KEYCODE_DPAD_RIGHT else null
        )
        if (step != Step.IDLE) {
            val first = raw.firstOrNull()
            if (first != null) handleRemapPress(first)
        } else {
            for (code in raw) {
                val mapped = if (pad.passthrough) code else profile.map(code)
                hatHeld.add(mapped)
                pad.state.pressed.add(mapped)
            }
        }
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.action == MotionEvent.ACTION_MOVE) {
            pad.passthrough = e.device?.name == PadEngineCtl.DEVICE_NAME
            val s = pad.state
            s.lx = e.getAxisValue(MotionEvent.AXIS_X)
            s.ly = e.getAxisValue(MotionEvent.AXIS_Y)
            s.rx = e.getAxisValue(MotionEvent.AXIS_Z)
            s.ry = e.getAxisValue(MotionEvent.AXIS_RZ)
            s.lt = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
            s.rt = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
            handleHat(e.getAxisValue(MotionEvent.AXIS_HAT_X), e.getAxisValue(MotionEvent.AXIS_HAT_Y))
            setDevice(e.device)
            pad.invalidate()
            return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val fromPad = e.isFromSource(InputDevice.SOURCE_GAMEPAD) || e.isFromSource(InputDevice.SOURCE_DPAD)
        val isPadKey = KeyEvent.isGamepadButton(e.keyCode) ||
            e.keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        if (!fromPad || !isPadKey) return super.dispatchKeyEvent(e)

        setDevice(e.device)
        pad.passthrough = e.device?.name == PadEngineCtl.DEVICE_NAME

        if (step != Step.IDLE) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) handleRemapPress(e.keyCode)
            return true
        }

        val mapped = if (pad.passthrough) e.keyCode else profile.map(e.keyCode)
        if (e.action == KeyEvent.ACTION_DOWN) pad.state.pressed.add(mapped)
        else if (e.action == KeyEvent.ACTION_UP) pad.state.pressed.remove(mapped)
        pad.invalidate()
        return true
    }

    private fun setDevice(d: InputDevice?) {
        if (d == null || d.id == device?.id) return
        device = d
        var info = "Controle: ${d.name}"
        if (Build.VERSION.SDK_INT >= 31) {
            val b = d.batteryState
            if (b.isPresent && !b.capacity.isNaN()) info += "\nBateria: ${(b.capacity * 100).toInt()}%"
        }
        status.text = info
    }

    private fun testVibration() {
        val d = device ?: return
        val amp = max(1, (profile.vibration * 255).toInt())
        if (Build.VERSION.SDK_INT >= 31) {
            val v = d.vibratorManager.defaultVibrator
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(400, amp))
        } else {
            @Suppress("DEPRECATION")
            d.vibrator.vibrate(400)
        }
    }
}
