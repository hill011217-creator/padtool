package com.example.padtool

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.Locale

/** Liga, desliga e configura o motor (PadEngine) que roda em segundo plano pelo Shizuku. */
object PadEngineCtl {
    /** Nome do controle virtual que o motor cria. */
    const val DEVICE_NAME = "PadTool Virtual Controller"

    private const val CFG = "/data/local/tmp/padtool.cfg"
    private const val PID = "/data/local/tmp/padtool.pid"
    private const val STATUS = "/data/local/tmp/padtool.status"
    private const val LOG = "/data/local/tmp/padtool.log"

    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    // O método newProcess é privado nas versões novas da API, então chamo por reflexão.
    fun sh(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (t: Throwable) {
            "ERRO: ${t.cause ?: t}"
        }
    }

    private fun cfgText(p: Profile, enabled: Boolean): String {
        val remap = p.remap.entries.joinToString(",") { "${it.key}:${it.value}" }
        return "enabled=${if (enabled) 1 else 0}\n" +
            "deadzone=${String.format(Locale.US, "%.4f", p.deadzone)}\n" +
            "curve=${String.format(Locale.US, "%.4f", p.curve)}\n" +
            "invertY=${if (p.invertY) 1 else 0}\n" +
            "remap=$remap\n"
    }

    // O texto só tem letras, números e : , . = e quebras de linha, então é seguro no printf.
    private fun writeCfg(text: String) {
        val esc = text.replace("\n", "\\n")
        sh("printf '$esc' > $CFG")
    }

    /** Envia os ajustes atuais para o motor (ele aplica na hora). */
    fun pushConfig(p: Profile) = writeCfg(cfgText(p, true))

    fun start(apk: String, p: Profile): String {
        writeCfg(cfgText(p, true))
        val script = "P=\$(cat $PID 2>/dev/null); " +
            "if [ -n \"\$P\" ] && grep -qa PadEngine /proc/\$P/cmdline 2>/dev/null; then echo JA_RODANDO; else " +
            "if command -v setsid >/dev/null 2>&1; then L=setsid; else L=; fi; " +
            "CLASSPATH='$apk' nohup \$L app_process /system/bin com.example.padtool.PadEngine " +
            "> $LOG 2>&1 < /dev/null & " +
            "echo INICIADO; fi"
        return sh(script)
    }

    fun stop(): String {
        val script = "printf 'enabled=0\\n' > $CFG; sleep 1; " +
            "P=\$(cat $PID 2>/dev/null); " +
            "if [ -n \"\$P\" ] && grep -qa PadEngine /proc/\$P/cmdline 2>/dev/null; then kill \$P; fi; " +
            "echo PARADO"
        return sh(script)
    }

    /** Primeira linha: RODANDO ou PARADO. Depois, o que o motor escreveu sobre si mesmo. */
    fun status(): String {
        if (!alive()) return "SEM_SHIZUKU"
        if (!granted()) return "SEM_PERMISSAO"
        val script = "P=\$(cat $PID 2>/dev/null); " +
            "if [ -n \"\$P\" ] && grep -qa PadEngine /proc/\$P/cmdline 2>/dev/null; then " +
            "echo RODANDO; cat $STATUS 2>/dev/null; else echo PARADO; fi"
        return sh(script)
    }

    fun log(): String = sh("cat $LOG 2>/dev/null | tail -n 15")
}
