package com.example.padtool

import android.content.Context
import android.view.KeyEvent
import kotlin.math.hypot
import kotlin.math.pow

/** Perfil de configuração. Por enquanto existe um só; depois vira um por jogo. */
data class Profile(
    var deadzone: Float = 0.10f,   // 0..0.5, zona morta radial dos analógicos
    var curve: Float = 1.0f,       // 0.5..3, expoente da curva (1 = linear)
    var invertY: Boolean = false,
    var vibration: Float = 0.6f,   // 0..1, intensidade da vibração
    val remap: MutableMap<Int, Int> = mutableMapOf()  // keyCode físico -> keyCode destino
) {
    /** Aplica zona morta radial + curva. Entrada e saída em -1..1. */
    fun stick(x: Float, y: Float): Pair<Float, Float> {
        val mag = hypot(x, y)
        if (mag <= deadzone || mag == 0f) return 0f to 0f
        val scaled = ((mag - deadzone) / (1f - deadzone)).coerceIn(0f, 1f)
        val out = scaled.pow(curve)
        val ox = x / mag * out
        var oy = y / mag * out
        if (invertY) oy = -oy
        return ox to oy
    }

    fun trigger(v: Float): Float = v.coerceIn(0f, 1f).pow(curve)

    /** Botão físico -> botão depois do remapeamento. */
    fun map(code: Int): Int = remap[code] ?: code
}

/** Nome do botão no padrão PlayStation. */
fun buttonName(code: Int): String = when (code) {
    KeyEvent.KEYCODE_BUTTON_A -> "✕"
    KeyEvent.KEYCODE_BUTTON_B -> "○"
    KeyEvent.KEYCODE_BUTTON_X -> "□"
    KeyEvent.KEYCODE_BUTTON_Y -> "△"
    KeyEvent.KEYCODE_BUTTON_L1 -> "L1"
    KeyEvent.KEYCODE_BUTTON_R1 -> "R1"
    KeyEvent.KEYCODE_BUTTON_L2 -> "L2"
    KeyEvent.KEYCODE_BUTTON_R2 -> "R2"
    KeyEvent.KEYCODE_BUTTON_THUMBL -> "L3"
    KeyEvent.KEYCODE_BUTTON_THUMBR -> "R3"
    KeyEvent.KEYCODE_BUTTON_SELECT -> "Share"
    KeyEvent.KEYCODE_BUTTON_START -> "Options"
    KeyEvent.KEYCODE_BUTTON_MODE -> "PS"
    KeyEvent.KEYCODE_DPAD_UP -> "↑"
    KeyEvent.KEYCODE_DPAD_DOWN -> "↓"
    KeyEvent.KEYCODE_DPAD_LEFT -> "←"
    KeyEvent.KEYCODE_DPAD_RIGHT -> "→"
    else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

class ProfileStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("profile", Context.MODE_PRIVATE)

    fun load(): Profile {
        val map = mutableMapOf<Int, Int>()
        sp.getString("remap", "")!!.split(",").filter { it.contains(":") }.forEach {
            val (a, b) = it.split(":")
            val from = a.toIntOrNull(); val to = b.toIntOrNull()
            if (from != null && to != null) map[from] = to
        }
        return Profile(
            deadzone = sp.getFloat("deadzone", 0.10f),
            curve = sp.getFloat("curve", 1.0f),
            invertY = sp.getBoolean("invertY", false),
            vibration = sp.getFloat("vibration", 0.6f),
            remap = map
        )
    }

    fun save(p: Profile) {
        sp.edit()
            .putFloat("deadzone", p.deadzone)
            .putFloat("curve", p.curve)
            .putBoolean("invertY", p.invertY)
            .putFloat("vibration", p.vibration)
            .putString("remap", p.remap.entries.joinToString(",") { "${it.key}:${it.value}" })
            .apply()
    }
}
