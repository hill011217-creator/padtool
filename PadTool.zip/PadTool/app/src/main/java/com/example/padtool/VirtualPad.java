package com.example.padtool;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * Roda como usuário "shell" (iniciado pelo Shizuku via app_process).
 * Cria um controle virtual em /dev/uhid, mexe o analógico esquerdo e remove o controle.
 * É só um TESTE: não mexe no controle real.
 */
public class VirtualPad {
    private static final String NAME = "PadTool Virtual Gamepad";

    private static final int UHID_DESTROY = 1;
    private static final int UHID_CREATE2 = 11;
    private static final int UHID_INPUT2 = 12;

    // O tamanho exato do evento depende do kernel; tento os dois valores conhecidos.
    private static final int[] SIZES = {4376, 4380};
    private static int eventSize = 0;

    // Descritor HID: gamepad com 4 eixos de 8 bits (X, Y, Z, Rz) e 14 botões.
    private static final int[] DESC = {
        0x05, 0x01, 0x09, 0x05, 0xA1, 0x01,
        0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35,
        0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x0E, 0x15, 0x00, 0x25, 0x01,
        0x75, 0x01, 0x95, 0x0E, 0x81, 0x02,
        0x75, 0x01, 0x95, 0x02, 0x81, 0x03,
        0xC0
    };

    public static void main(String[] args) throws Exception {
        int seconds = 6;
        if (args.length > 0) seconds = Integer.parseInt(args[0]);

        RandomAccessFile f;
        try {
            f = new RandomAccessFile("/dev/uhid", "rw");
        } catch (Exception e) {
            say("FALHA ao abrir /dev/uhid: " + e);
            return;
        }
        say("/dev/uhid aberto com sucesso.");

        try {
            send(f, createEvent());
            say("Controle virtual criado (tamanho de evento " + eventSize + ").");
            Thread.sleep(1500);

            int steps = seconds * 1000 / 16;
            for (int i = 0; i < steps; i++) {
                double a = (i * 16) / 2000.0 * 2 * Math.PI;
                int lx = clamp(128 + (int) (110 * Math.sin(a)));
                int ly = clamp(128 + (int) (110 * Math.cos(a)));
                int buttons = (i % 120 < 60) ? 1 : 0;
                send(f, inputEvent(lx, ly, 128, 128, buttons));
                Thread.sleep(16);
            }
            send(f, inputEvent(128, 128, 128, 128, 0));
            Thread.sleep(300);
            say("Movimentos enviados.");

            send(f, simple(UHID_DESTROY));
            Thread.sleep(500);
            say("Controle virtual removido.");
        } catch (Throwable t) {
            say("FALHA durante o teste: " + t);
        } finally {
            try { f.close(); } catch (IOException ignored) { }
        }
    }

    private static void say(String s) {
        System.out.println(s);
        System.out.flush();
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    private static void send(RandomAccessFile f, byte[] data) throws IOException {
        if (eventSize != 0) {
            f.write(pad(data, eventSize));
            return;
        }
        IOException last = null;
        for (int s : SIZES) {
            try {
                f.write(pad(data, s));
                eventSize = s;
                return;
            } catch (IOException e) {
                last = e;
            }
        }
        throw last;
    }

    private static byte[] pad(byte[] d, int size) {
        byte[] r = new byte[size];
        System.arraycopy(d, 0, r, 0, Math.min(d.length, size));
        return r;
    }

    private static byte[] simple(int type) {
        ByteBuffer b = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(type);
        return b.array();
    }

    private static void putStr(ByteBuffer b, String s, int len) {
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
        int start = b.position();
        b.put(bytes, 0, Math.min(bytes.length, len - 1));
        b.position(start + len);
    }

    private static byte[] createEvent() {
        ByteBuffer b = ByteBuffer.allocate(4376).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(UHID_CREATE2);
        putStr(b, NAME, 128);
        putStr(b, "padtool/virtual0", 64);
        putStr(b, "", 64);
        b.putShort((short) DESC.length);
        b.putShort((short) 3);      // BUS_USB
        b.putInt(0x1209);           // vendor (faixa de testes)
        b.putInt(0x7A01);           // product
        b.putInt(1);                // version
        b.putInt(0);                // country
        for (int d : DESC) b.put((byte) d);
        return b.array();
    }

    private static byte[] inputEvent(int lx, int ly, int rx, int ry, int buttons) {
        ByteBuffer b = ByteBuffer.allocate(4 + 2 + 6).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(UHID_INPUT2);
        b.putShort((short) 6);
        b.put((byte) lx);
        b.put((byte) ly);
        b.put((byte) rx);
        b.put((byte) ry);
        b.put((byte) (buttons & 0xFF));
        b.put((byte) ((buttons >> 8) & 0x3F));
        return b.array();
    }
}
